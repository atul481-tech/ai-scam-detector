# AI Scam Detector — starter MVP

## What this version does
- Hindi/English interface
- Checks visible URL patterns locally in the browser
- Does not send pasted URLs to a server
- Includes official Indian cybercrime resources
- Installable Progressive Web App (PWA) foundation

## Important limitations
This is NOT an AI classifier and does NOT query a live threat-intelligence database. The score is a heuristic warning score, not a probability. A low score does not prove a site is safe. Do not enter passwords, OTPs, UPI PINs, card details, or other secrets. Do not automatically open scanned URLs.

## Deploy free with GitHub Pages
1. Create/sign in to https://github.com
2. Create a **public** repository named `ai-scam-detector`.
3. Upload all files and folders from this ZIP (keep `index.html` at repository root).
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**.
6. Select branch `main`, folder `/ (root)`, then Save.
7. Wait for the published `https://YOUR-USERNAME.github.io/ai-scam-detector/` URL.

GitHub Pages is available on GitHub Free for public repositories. Keep this repo public only if you are comfortable publishing the source code.

## Install on Android
1. Open the published HTTPS site in Chrome on Android.
2. Tap Chrome's ⋮ menu.
3. Choose **Install app** or **Add to Home screen** if offered.
4. Confirm. This creates an app-like PWA shortcut; it is not a Play Store APK.

## Before commercial launch
Add a secure server-side integration to a commercial threat-intelligence provider (for example Google Web Risk), protect API credentials on the server, add rate limits, privacy notice, abuse handling, testing, and legal review. Google Safe Browsing API is restricted to non-commercial use; do not use it for a revenue-generating service.
